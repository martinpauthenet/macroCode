import matplotlib.pyplot as plt
import matplotlib.colors as colors
import math
#import config
import numpy as np
#from scipy.sparse import csc_matrix, csr_matrix, linalg as sla, identity
#parameters
#Ly,Lx,ny,nx,dy,dx,nu,rho,Ulid,dt = config.sharedparameters()
#R,ms,K,gamma,centers0 = config.get_sphereParameters()
from shutil import copyfile

def flowRateOF(log,axe):
    copyfile(log, 'ran.log')
    r = open('ran.log', 'r')
    line = r.readline()
    time=[]
    Ux=[]
    while len(line)>0:
      if 'Time = ' in line and len(line.split()) == 3:
        T = float(line.split()[-1])
        #print line
        while 'Averaged velocity <U>' not in line and len(line)>0:
          line = r.readline()
        if len(line)>0:
          try:
              #print line
              #print float(line.split()[4][:]), T
              Ux.append(float(line.split()[4][:])) # Ux
              time.append(T)
              #print line
          except:''
      line = r.readline()
    r.close()
    time=np.array(time)
    Ux=np.array(Ux)
    axe.plot(time[1:],Ux[1:],label='average velocity',color='k')
    return

if __name__ == '__main__' :

        fig, ax = plt.subplots(dpi=100)
        for pref in ['./']:
         log = pref+'run.log'
         flowRateOF(log,ax)
        ax.legend(loc=0)

        plt.show()

