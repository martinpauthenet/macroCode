cp constant/polyMesh/blockMeshDict .
rm -r constant/polyMesh/*
mv blockMeshDict constant/polyMesh/
blockMesh
decomposePar
#sbatch slurm.cmd
#mpirun -np 4 movingVANS -parallel > run.log &
