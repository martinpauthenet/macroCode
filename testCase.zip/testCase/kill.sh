pkill movingVANS
