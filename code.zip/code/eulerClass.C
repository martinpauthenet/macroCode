#include "eulerClass.H"

Euler::~Euler() {
}
Euler::Euler(const Foam::fvMesh& maille, const Foam::volVectorField& U, KDTreeEigenMatrixAdaptor< Eigen::Matrix<double,Dynamic,Dynamic>,nanoflann::metric_L2>& mat_index, const Eigen::Matrix<double, Dynamic, Dynamic>& maty, double *LenRef, double temps) : maille(maille), U(U), mat_index(mat_index), maty(maty) {

Foam::dictionary porousSolidProperties(Foam::IFstream("constant/porousSolidProperties")());

Foam::dictionary transportProperties(Foam::IFstream("constant/transportProperties")());

Foam::dimensionedScalar nu_foam(transportProperties.lookup("nu")); //the value of fluid kinematic viscosity
nu = nu_foam.value();
rhob = Foam::readScalar(porousSolidProperties.lookup("rhob")); //the value of fluid density
mu = nu*rhob;
nh = Foam::readScalar(porousSolidProperties.lookup("nh")); //# the beam is discretized in nh-1 elements
rhos = Foam::readScalar(porousSolidProperties.lookup("rhos")); //the value of solid density
double por;
por = Foam::readScalar(porousSolidProperties.lookup("porosity")); // porosity
solid_fraction_0 = 1.-por; // solidfraction

nuv = U.size();
Foam::Info<< nuv << Foam::endl;

//################################################### BEAM
Lx = Foam::readScalar(porousSolidProperties.lookup("Lx"));
Ly = Foam::readScalar(porousSolidProperties.lookup("Ly"));
H = Foam::readScalar(porousSolidProperties.lookup("H"));
dh = H/(nh-1); //# size of an infinitesimal beam
Nhair = Foam::readScalar(porousSolidProperties.lookup("Nhair")); //# number of hairs
Nchild = Foam::readScalar(porousSolidProperties.lookup("Nchild")); //# paire

l_canopy = Lx;// - 2.*H;
DS = l_canopy/(Nhair*(1+Nchild));
//REV
lx_ = DS;
ly_ = dh;
//d = solid_fraction_0*std::sqrt(pow(DS,2)/(M_PI/4.)); //beam diameter
d = Foam::readScalar(porousSolidProperties.lookup("d")); //# number of hairs

double l_m;
l_m = M_PI/4./0.8*d;
Foam::Info << "fiber diameter " << d << " l_m " << l_m << " lx_ " << lx_ <<Foam::endl;

discr = 5*(Lx/lx_);
nx = discr+1;
discr = 5*(Ly/ly_);
ny = discr+1;
Foam::Info<< "nx,ny minima " << nx << "   " << ny << Foam::endl;
findnxnyuv();

//dx_ = Lx/(nx-1);
//dy_ = Ly/(ny-1);
coef = 16./(M_PI*pow(d,4)*rhos);

S_time = temps;

new_theta = MatrixXf::Zero(Nhair,nh-1);
TEMP_theta = MatrixXf::Zero(Nhair,nh-1);
theta = MatrixXf::Zero(Nhair,nh-1);
poroS = MatrixXf::Zero(Nhair,nh-1);
theta_past = MatrixXf::Zero(Nhair,nh-1);
X = MatrixXf::Zero(Nhair,nh);
Y = MatrixXf::Zero(Nhair,nh);
new_X = MatrixXf::Zero(Nhair,nh);
new_Y = MatrixXf::Zero(Nhair,nh);
xInterp_past = MatrixXf::Zero(Nhair,nh-1);
yInterp_past = MatrixXf::Zero(Nhair,nh-1);
xInterp = MatrixXf::Zero(Nhair,nh-1);
yInterp = MatrixXf::Zero(Nhair,nh-1);

cXInterp = MatrixXf::Zero(Nchild*Nhair,nh-1);
cYInterp = MatrixXf::Zero(Nchild*Nhair,nh-1);
cT = MatrixXf::Zero(Nchild*Nhair,nh-1);
cX = MatrixXf::Zero(Nchild*Nhair,nh);
cY = MatrixXf::Zero(Nchild*Nhair,nh);

uXY = MatrixXf::Zero(Nhair,nh-1);
vXY = MatrixXf::Zero(Nhair,nh-1);
us = MatrixXf::Zero(Nhair,nh-1);
vs = MatrixXf::Zero(Nhair,nh-1);
us_old = MatrixXf::Zero(Nhair,nh-1);
vs_old = MatrixXf::Zero(Nhair,nh-1);
cUs = MatrixXf::Zero(Nchild*Nhair,nh-1);
cVs = MatrixXf::Zero(Nchild*Nhair,nh-1);

solid_fraction = VectorXf::Zero(nuv);
solid_fraction_K = VectorXf::Zero(nuv);
Sphase = VectorXf::Zero(nuv);

B_bending = Foam::readScalar(porousSolidProperties.lookup("B_bending"));
B = VectorXf::Constant(nh-2, B_bending );

double umax;
umax = max(mag(U)).value();
double Cy;
Cy = rhob*pow(umax,2)*d*pow(H,3)/(2*B_bending);
Foam::Info<< "Cauchy number " << Cy << Foam::endl;

double gamma;
gamma = Foam::readScalar(porousSolidProperties.lookup("gamma"));
dissip_const = VectorXf::Constant(nh-2, gamma*std::sqrt(4.*B.maxCoeff()/coef)*H*H/d); // a verifier
// options
//adjustableTimeStep = true;
nimplocit = Foam::readScalar(porousSolidProperties.lookup("n_ite_mplicit"));
err_implocit = Foam::readScalar(porousSolidProperties.lookup("err_mplicit"));

limangle = Foam::readScalar(porousSolidProperties.lookup("deg"));
time_scale = 0.1 * std::sqrt(pow(dh,2)/B.maxCoeff()*(M_PI*pow(d,4)*rhos)/4);
//Foam::Info<< "solid time scale is " << time_scale << " s" << Foam::endl;

plo = 0;
dt = time_scale;
dt_Old = time_scale;

//kernel
kx = std::max(round(0.5*(nx-1)/(Lx/lx_)),1.);
//ky = round(0.5*(ny-1)/(Ly/ly_));
solid_ghost_inf = MatrixXf::Zero(kx,ny);
solid_ghost_sup = MatrixXf::Zero(kx,ny);
}

double Euler::get_time_scale(){
return time_scale;
}

double Euler::get_theta(int nhair, int nh){
return theta(nhair,nh);
}
void Euler::set_theta(int nhair, int nh, double val){
theta(nhair,nh) = val;
}
double Euler::get_us(int nhair, int nh){
return us(nhair,nh);
}
void Euler::set_us(int nhair, int nh, double val){
us(nhair,nh) = val;
}
double Euler::get_vs(int nhair, int nh){
return vs(nhair,nh);
}
void Euler::set_vs(int nhair, int nh, double val){
vs(nhair,nh) = val;
}

void Euler::set_Cauchy_tozero(){
max_Cy = 0.;
max_Re = 0.;
}

double Euler::max_Cauchy(){
return max_Cy;
}
double Euler::max_Reynolds(){
return max_Re;
}

double Euler::diameter(){
return d;
}

int Euler::get_nh(){
return nh;
}
int Euler::get_Nhair(){
return Nhair;
}
/*int Euler::get_fiberNumber(){
int n;
for (n=0;n<Nhair;n++){
  if (inBlock(xInterp(n,0),yInterp(n,0))) return n;
  }
return -1;
}*/

void Euler::get_meta(double angle_yx,double angle_zx,double angleS,double *result_N,double *result_T,double v_N,double v_T,double porosity,double reynolds){
           /*reynolds = lenref/nu*sqrt(pow(uxy,2),pow(vxy,2));
           if (reynolds < 100.){*/
                // Query point:  points in wich we will ask for NN in the kdtree
                std::vector<double> query_pt(4);
                query_pt[1] = std::fabs(angle_zx);
                query_pt[2] = std::fabs(angle_yx + angleS*180./M_PI);// /180.*M_PI);
                query_pt[0] = reynolds;
                query_pt[3] = porosity;
                double a;
                a = kdtree_search<double>(mat_index, query_pt);
            // this check is done for symmetry reasons
            // because in this case the 11 and 22 components have to be switched
            if(std::fabs(angle_zx) > 45){
                // search in the database the best fit for the 4 parameters above
                (*result_T) = maty(a,1) * v_T;
                (*result_N) = maty(a,2) * v_N;
                //K[j].zz() = maty(a,0);
            }
            else{
                (*result_T) = maty(a,0) * v_T;
                (*result_N) = maty(a,2) * v_N;
                //K[j].zz() = maty(a,1);
                }
}

void Euler::permeability(double uxy, double vxy, double porosity,double angleS,double *kuxx,double *kuyy, double &lenref, double &porosity_eff){
double angle_yx,angle_zx;
        if      (vxy == 0.) angle_yx = 0.;
        else if (uxy == 0.){
             if      (vxy > 0.) angle_yx = +90.;
             else if (vxy < 0.) angle_yx = -90.;
             }
        else angle_yx = atan(vxy / uxy) *(180.0 / M_PI);
        angle_zx = 0.;
double Cy,mP,v_N,v_T,result_N,result_T;
double RetN,RetT,CD;
v_T = uxy*sin(angleS) + vxy*cos(angleS);
v_N = uxy*cos(angleS) - vxy*sin(angleS);
       double reynolds,umax;
       reynolds = d/nu*std::sqrt((uxy*uxy)+(vxy*vxy));
       umax = reynolds*nu/d;
       Cy = rhob*(umax*umax)*d*H*H*H/(2.*B_bending);
       if (Cy>max_Cy) max_Cy = Cy;
       double ReT; 
       ReT = d/nu*std::fabs(v_T);
       double ReN; 
       ReN= d/nu*std::fabs(v_N);
       if (max_Re < reynolds) max_Re = reynolds;
       porosity_eff = porosity;
       if (porosity>0.8) {
         porosity_eff=0.8;
         }
       if (porosity<0.4) {
         porosity_eff=0.4;
         }
       lenref = d*std::sqrt(M_PI/2.)/std::sqrt(1.-porosity_eff);
       double reynolds_eff,temp;
       reynolds_eff = reynolds;
     if (reynolds_eff < 100.){
       get_meta(angle_yx,angle_zx,angleS,&result_N,&result_T,v_N,v_T,porosity_eff,reynolds_eff);
       if (porosity>0.8 || porosity<0.4) {
       temp = (1-porosity)*(1-porosity)/(porosity*porosity*porosity)/(1-porosity_eff)/(1-porosity_eff)*(porosity_eff*porosity_eff*porosity_eff);
         result_N*=temp;
         result_T*=temp;
         }
       }else{
       reynolds_eff = 0.;
       //get Darcy
       get_meta(angle_yx,angle_zx,angleS,&result_N,&result_T,v_N,v_T,porosity_eff,reynolds_eff);
       if (porosity>0.8 || porosity<0.4){
       temp = (1-porosity)*(1-porosity)/(porosity*porosity*porosity)/(1-porosity_eff)/(1-porosity_eff)*(porosity_eff*porosity_eff*porosity_eff);
         result_N*=temp;
         result_T*=temp;
         }
       if (std::fabs(ReN)>0.){
       RetN=porosity*porosity*result_N/v_N/(0.88*std::sqrt(M_PI/2.));
       //std::cout << RetN << std::endl;
       if (ReN>RetN){
         result_N*=ReN/RetN;
         }
       }
       CD=0.001;
       if (std::fabs(ReT)>0.){
       RetT=porosity*std::sqrt(1.-porosity)/std::sqrt(M_PI/2.)*result_T/(v_T*CD);
       if (ReT>RetT){
         result_T*=ReT/RetT;
         }
       }
       }
(*kuxx) = +(result_T*sin(angleS)+result_N*cos(angleS));
(*kuyy) = +(result_T*cos(angleS)-result_N*sin(angleS));
    //mP = std::max( std::fabs(result_T), std::fabs(result_N) );
}

double Euler::KC(double porosity){
//return 1.;
return (1-porosity)*(1-porosity)/(porosity*porosity*porosity);
}
double Euler::Forch(double porosity){
//return 1.;
return (1-porosity)*porosity;
}

double Euler::getxmin(){
return xmin;
}
double Euler::getxmax(){
return xmax;
}
double Euler::getymin(){
return ymin;
}
double Euler::getymax(){
return ymax;
}

void Euler::findnxnyuv(){
  int i;
  xmin = xFDPoints_uv(0);
  i=1;
  while (xFDPoints_uv(i-1)<xFDPoints_uv(i)){
   i++;   
  }
  nx = i;
  ny = (nuv-nx)/nx + 1;

  xmin = xFDPoints_uv(0);
  xmax = xFDPoints_uv(0);
  ymin = yFDPoints_uv(0);
  ymax = yFDPoints_uv(0);
  for (i=1;i<nuv;i++){
    if (xmin > xFDPoints_uv(i)) xmin = xFDPoints_uv(i);
    if (xmax < xFDPoints_uv(i)) xmax = xFDPoints_uv(i);
    if (ymin > yFDPoints_uv(i)) ymin = yFDPoints_uv(i);
    if (ymax < yFDPoints_uv(i)) ymax = yFDPoints_uv(i);
  }
  dx = xFDPoints_uv(1) - xFDPoints_uv(0);
  xmin -= 0.5*dx;
  xmax += 0.5*dx;
  ymin -= 0.5*dx;
  ymax += 0.5*dx;

  xmin = round(xmin/Ly*1e6)*Ly*1e-6;
  xmax = round(xmax/Ly*1e6)*Ly*1e-6;
  ymin = round(ymin/Ly*1e6)*Ly*1e-6;
  ymax = round(ymax/Ly*1e6)*Ly*1e-6;

}

double Euler::xFDPoints_uv(int i){
return maille.C()[i][0];
}
double Euler::yFDPoints_uv(int i){
return maille.C()[i][1];
}
double Euler::u(int i){
return U[i][0];
}
double Euler::v(int i){
return U[i][1];
}

void Euler::setInterp(){
  int n,m;
  for (m=0; m<nh-1; m++){
    for (n=0; n<Nhair; n++){
      xInterp(n,m) = (X(n,m)+X(n,m+1))/2.;
      yInterp(n,m) = (Y(n,m)+Y(n,m+1))/2.;
      }
    }
  }

void Euler::setInterp_past(){
  int etage,hair;
  for (etage=0;etage<nh-1;etage++){
      for (hair=0;hair<Nhair;hair++){
        xInterp_past(hair,etage) = xInterp(hair,etage);
        yInterp_past(hair,etage) = yInterp(hair,etage);
        }
      }
  }

void Euler::setCInterp(){
  int n,i,m;
  for (m=0; m<nh-1; m++){
    for (n=0; n<Nhair; n++){
    for (i=0; i<Nchild; i++){
        cXInterp(n*Nchild+i,m) = (cX(n*Nchild+i,m)+cX(n*Nchild+i,m+1))/2.;
        cYInterp(n*Nchild+i,m) = (cY(n*Nchild+i,m)+cY(n*Nchild+i,m+1))/2.;
        }
      }
    }
  }

void Euler::broadcast_thetaAndUs_to_childrens(){
int n,j,m;
for (n=1; n<nh-1; n++){
  for (m=0; m<Nchild/2; m++){
    //cT(m,n) = theta(0,n);
    cT(0*Nchild+m,n) = interpolent(cX(0*Nchild+m,0),X(Nhair-1,0)-Lx,X(0,0),theta(Nhair-1,n),theta(0,n));
    cUs(0*Nchild+m,n) = interpolent(cX(0*Nchild+m,0),X(Nhair-1,0)-Lx,X(0,0),us(Nhair-1,n),us(0,n));
    cVs(0*Nchild+m,n) = interpolent(cX(0*Nchild+m,0),X(Nhair-1,0)-Lx,X(0,0),vs(Nhair-1,n),vs(0,n));
    }
  for (m=Nchild/2; m<Nchild; m++){
    //cT((Nhair-1)*Nchild+m,n) = theta(Nhair-1,n);
    cT((Nhair-1)*Nchild+m,n) = interpolent(cX((Nhair-1)*Nchild+m,0),X(Nhair-1,0),X(0,0)+Lx,theta(Nhair-1,n),theta(0,n));
    cUs((Nhair-1)*Nchild+m,n) = interpolent(cX((Nhair-1)*Nchild+m,0),X(Nhair-1,0),X(0,0)+Lx,us(Nhair-1,n),us(0,n)); 
    cVs((Nhair-1)*Nchild+m,n) = interpolent(cX((Nhair-1)*Nchild+m,0),X(Nhair-1,0),X(0,0)+Lx,vs(Nhair-1,n),vs(0,n));
    }
  }
for (n=0;n<Nhair-1;n++){
  for (m=1;m<nh-1;m++){
    for (j=Nchild/2;j<Nchild;j++){
      cT(n*Nchild+j,m) = interpolent(cX(n*Nchild+j,0),X(n,0),X(n+1,0),theta(n,m),theta(n+1,m));
      cUs(n*Nchild+j,m) = interpolent(cX(n*Nchild+j,0),X(n,0),X(n+1,0),us(n,m),us(n+1,m));
      cVs(n*Nchild+j,m) = interpolent(cX(n*Nchild+j,0),X(n,0),X(n+1,0),vs(n,m),vs(n+1,m));
      }
    for (j=0;j<Nchild/2;j++){
      cT((n+1)*Nchild+j,m) = interpolent(cX((n+1)*Nchild+j,0),X(n,0),X(n+1,0),theta(n,m),theta(n+1,m));
      cUs((n+1)*Nchild+j,m) = interpolent(cX((n+1)*Nchild+j,0),X(n,0),X(n+1,0),us(n,m),us(n+1,m));
      cVs((n+1)*Nchild+j,m) = interpolent(cX((n+1)*Nchild+j,0),X(n,0),X(n+1,0),vs(n,m),vs(n+1,m));
      }
    }
  }
}

void Euler::draw_hairs(){
int n,m;
for (n=0;n<Nhair;n++){
for (m=1;m<nh;m++){
  X(n,m) = X(n,m-1) + dh*sin(theta(n,m-1));
  Y(n,m) = Y(n,m-1) + dh*cos(theta(n,m-1));
  }
}
}

void Euler::draw_childrens(){
int n,j,m;
for (n=0;n<Nhair;n++){
for (j=0;j<Nchild;j++){
for (m=1;m<nh;m++){
  cX(n*Nchild+j,m) = cX(n*Nchild+j,m-1) + dh*sin(cT(n*Nchild+j,m-1));
  cY(n*Nchild+j,m) = cY(n*Nchild+j,m-1) + dh*cos(cT(n*Nchild+j,m-1));
  }
}
}
}

double Euler::interpolent(double x,double xR,double xL,double yR,double yL){
  double dydx,interp_value;
  dydx = ( yR - yL ) / ( xR - xL );
  interp_value = yL + dydx * ( x - xL );
  return interp_value;
}

void Euler::initialize_solid_phase(){
int m,n;
if (Nhair>1){
  for (n=0; n<Nhair; n++){
    X(n,0) = n*(Nchild+1)*DS - 0.5*l_canopy+0.5*Nchild*DS;
    }
  }

for (n=0; n<Nhair; n++){
  for (m=0; m<Nchild/2; m++){
  cX(n*Nchild+m,0) = X(n,0) - (Nchild/2 - m)*DS;
  }
  for (m=Nchild/2; m<Nchild; m++){
  cX(n*Nchild+m,0) = X(n,0) + (1 - Nchild/2 + m)*DS;
  }
}
  draw_hairs();
  setInterp();
  setInterp_past();

  broadcast_thetaAndUs_to_childrens();
  draw_childrens();
  int i;
  for (m=0; m<nh-1; m++){
    for (n=0; n<Nhair; n++){
    for (i=0; i<Nchild; i++){
        cXInterp(n*Nchild+i,m) = (cX(n*Nchild+i,m)+cX(n*Nchild+i,m+1))/2.;
        cYInterp(n*Nchild+i,m) = (cY(n*Nchild+i,m)+cY(n*Nchild+i,m+1))/2.;
        }
      }
    }
  for (n=0; n<Nhair; n++){
    for (m=0; m<nh; m++){
      new_X(n,m) = X(n,m);
      new_Y(n,m) = Y(n,m);
      }
    }
}

void Euler::solid_coordinates(int i,double *aS,double *Usx,double *Usy){
if (yFDPoints_uv(i)<1.5*H){
  int m,n;
  double dist_test, dmin;
  m=0;
  n=0;
  dmin = distance(xFDPoints_uv(i),yFDPoints_uv(i),xInterp(0,0),yInterp(0,0));
  for (n=0;n<Nhair;n++){
//  if (inBlock(xInterp(n,0),yInterp(n,0))){
    for (m=0;m<nh-1;m++){
      dist_test = distance(xFDPoints_uv(i),yFDPoints_uv(i),xInterp(n,m),yInterp(n,m));
      if (dist_test < dmin){
        dmin = dist_test;
        (*aS) =theta(n,m); 
        (*Usx)=us(n,m);
        (*Usy)=vs(n,m);
        }
      }
//    }
    }
  int j;
  for (n=0;n<Nhair;n++){
  for (j=0;j<Nchild;j++){
  for (m=0;m<nh-1;m++){
    dist_test = distance(xFDPoints_uv(i),yFDPoints_uv(i),cXInterp(n*Nchild+j,m),cYInterp(n*Nchild+j,m));
    if (dist_test < dmin){
      dmin = dist_test;
      (*aS) =cT(n*Nchild+j,m);
      (*Usx)=cUs(n*Nchild+j,m);
      (*Usy)=cVs(n*Nchild+j,m);
      }
    }
   }
  }
  }
else{
  (*aS) =0.;
  (*Usx)=0.;
  (*Usy)=0.;
  }
  }

double Euler::local_solid_fraction(int i){
  return solid_fraction_K(i);
  //return solid_fraction(i);
  }
double Euler::get_phaseS(int i){
  return Sphase(i);
}

void Euler::spread_solid_fraction(){
  int i,j;
  for (i=0; i<nuv; i++){ 
    solid_fraction(i)=0.;
    Sphase(i)=0.;
    }
  for(i=0;i<kx;i++){
  for(j=0;j<ny;j++){
    solid_ghost_sup(i,j) = 0.;
    solid_ghost_inf(i,j) = 0.;
    }
    }
  write_sf();
  //smooth solid fraction
  kernel(1);
}

void Euler::kernel(int sweep){
  int ij,ky,i,j,N,ii,jj,ii_,jj_,n_sweep;  
  ky = kx;
  N = (2*kx+1)*(2*ky+1);
  for (n_sweep=0; n_sweep<sweep; n_sweep++){
  for (ij=0; ij<nuv; ij++){
    solid_fraction_K(ij)=0.;
    i = ij%nx;
    j = ij/nx;
    for (ii=-kx; ii<kx+1; ii++){
      for (jj=-ky; jj<ky+1; jj++){
      //symmetry
      ii_ = i + ii;
      jj_ = j + jj;
      //if (ii_ < 0) ii_ = -ii_;
      //else if (ii_ > nx-1) ii_ = 2*(nx-1)-ii_;
      if (jj_ < 0) {jj_ = -jj_;}
      else if (jj_ > ny-1) {jj_ = 2*(ny-1)-jj_;}
      if (ii_ < 0)         {solid_fraction_K(ij) += solid_ghost_inf(      -ii_-1,jj_);}
      else if (ii_ > nx-1) {solid_fraction_K(ij) += solid_ghost_sup(ii_-(nx-1)-1,jj_);}
      else                 {solid_fraction_K(ij) += solid_fraction(jj_*(nx)+ii_);}
      }
    }
    solid_fraction_K(ij) /= N;
    }
    /*if (sweep>1 and n_sweep<sweep-1){
    for (ij=0; ij<nuv; ij++) solid_fraction(ij)=solid_fraction_K(ij);
    }*/
  }
}

double Euler::xghost_sup(int i){
return xmax + i*dx + 0.5*dx;
}
double Euler::xghost_inf(int i){
return xmin - i*dx - 0.5*dx;
}
double Euler::yghost(int j){
return ymin + j*dx + 0.5*dx;
}

void Euler::fill_square(double xcenter,double ycenter,double angle){
        int i,j,w;
        double solid_fraction_0_eff,dx,dy,sD,xx,yy,lx_eff;
        double dmin; 
        dmin = lx_*lx_ + ly_*ly_;//pow(lx_,2)+pow(ly_,2);
        w=0;

        double l_m; 
        l_m = M_PI/4./0.8*d;//minimum space between the two opposite fibers that have the same nearest reference (slave of master)
        lx_eff = std::max(lx_*std::fabs(cos(angle)),l_m); //the unit cell is deformed due to the fibers inclination                                                     
        solid_fraction_0_eff = solid_fraction_0 + (0.8-solid_fraction_0)/(l_m-lx_)*(lx_eff-lx_);

        for(i=0;i<nuv;i++){
             xx = xFDPoints_uv(i) - xcenter;
             yy = yFDPoints_uv(i) - ycenter;
             if (std::fabs(xx-Lx)<std::fabs(xx)) xx-=Lx;
             if (std::fabs(xx+Lx)<std::fabs(xx)) xx+=Lx;
             dy = std::fabs(xx*sin(angle) + yy*cos(angle));
             dx = std::fabs(xx*cos(angle) - yy*sin(angle));
            if (dx<lx_eff && dy<ly_){
              if (yFDPoints_uv(i)>0.5*ly_) solid_fraction(i) += solid_fraction_0_eff*(1.-dx/lx_eff)*(1.-dy/ly_);
              else                         solid_fraction(i) += solid_fraction_0_eff*(1.-dx/lx_eff);
            }
          sD = dx*dx+dy*dy;//pow(dx,2)+pow(dy,2);
          if (sD<dmin){
            dmin=sD;
            w=i;
            }
          }
        if (inBlock(xcenter,ycenter)) Sphase(w)=1.;
        /*fill ghosts .. boulot deja fait par les autres mais pas le temps de parallelizer*/
        for(i=0;i<kx;i++){
        for(j=0;j<ny;j++){
          xx = xghost_sup(i) - xcenter;
          yy = yghost(j) - ycenter;
          if (std::fabs(xx-Lx)<std::fabs(xx)) xx-=Lx;
          if (std::fabs(xx+Lx)<std::fabs(xx)) xx+=Lx;
          dy = std::fabs(xx*sin(angle) + yy*cos(angle));
          dx = std::fabs(xx*cos(angle) - yy*sin(angle));
          if (dx<lx_eff && dy<ly_){
            if (yghost(j)>0.5*ly_) solid_ghost_sup(i,j) += solid_fraction_0_eff*(1.-dx/lx_eff)*(1.-dy/ly_);
            else                   solid_ghost_sup(i,j) += solid_fraction_0_eff*(1.-dx/lx_eff);
            }
          xx = xghost_inf(i) - xcenter;
          if (std::fabs(xx-Lx)<std::fabs(xx)) xx-=Lx;
          if (std::fabs(xx+Lx)<std::fabs(xx)) xx+=Lx;
          dy = std::fabs(xx*sin(angle) + yy*cos(angle));
          dx = std::fabs(xx*cos(angle) - yy*sin(angle));
          if (dx<=lx_eff && dy<=ly_){
            if (yghost(j)>0.5*ly_) solid_ghost_inf(i,j) += solid_fraction_0_eff*(1.-dx/lx_eff)*(1.-dy/ly_);
            else                   solid_ghost_inf(i,j) += solid_fraction_0_eff*(1.-dx/lx_eff);
            }
          } 
        }
        }

bool Euler::inBlock(double x,double y){
  if (x>=0.5*Lx)  x-=Lx;
  if (x<-0.5*Lx)  x+=Lx;
  return ((x<xmax && x>=xmin) && (y>=ymin && y<ymax));
}

bool Euler::inCharge(int hair){
  int d;
  d = hair % Foam::UPstream::nProcs();
  //std::cout << hair << "  " << d << "  " << Foam::UPstream::myProcNo() << std::endl;
  return (d == Foam::UPstream::myProcNo());
}

double Euler::distance(double x1,double y1,double x2,double y2){
  if      (std::fabs(x1 - (x2 - Lx)) < std::fabs(x1 - x2)) x2-=Lx;
  else if (std::fabs(x1 - (x2 + Lx)) < std::fabs(x1 - x2)) x2+=Lx;
  return std::sqrt(((x1-x2)*(x1-x2)) + ((y1-y2)*(y1-y2)));
}

void Euler::write_sf(){
      int hair,child,etage;
      for (etage=0;etage<nh-1;etage++){
        for (hair=0;hair<Nhair;hair++){
          fill_square(xInterp(hair,etage),yInterp(hair,etage),theta(hair,etage));
          for (child=0;child<Nchild;child++){
            fill_square(cXInterp(hair*Nchild+child,etage),cYInterp(hair*Nchild+child,etage),cT(hair*Nchild+child,etage));
            }
          }
        }
}

void Euler::update_solid_velocities(){
int etage,hair;
    // solid velocity
    for (hair=0;hair<Nhair;hair++){
      if (inCharge(hair)){
        for (etage=0;etage<nh-1;etage++){
        us(hair,etage) = (xInterp(hair,etage) - xInterp_past(hair,etage))/dt;
        vs(hair,etage) = (yInterp(hair,etage) - yInterp_past(hair,etage))/dt;
        }
        }
      }
return;
}

void Euler::nextShapes(double max_time,int rank){

    int etage,hair,nite;
      for (hair=0;hair<Nhair;hair++){
      if (inCharge(hair)){
    for (etage=0;etage<nh-1;etage++){
        us_old(hair,etage) = us(hair,etage);
        vs_old(hair,etage) = vs(hair,etage);
        }
        }
      }

    double err;    
    setInterp_past();
  double dtmax,dt_temp;
  dtmax = max_time - S_time;
  dt_temp = dt;
  dt = dtmax;
  for (hair=0;hair<Nhair;hair++) if (inCharge(hair)){ explicit_scheme(hair); }
  bool PASOK;

/*
  PASOK = dtpasok();
  if (PASOK) {
    dt = dt_temp;  
    // explicit step   
    for (hair=0;hair<Nhair;hair++) if (inCharge(hair)){ explicit_scheme(hair); }
    PASOK = dtpasok();
    while (not PASOK){
        dt *= 4.;
        for (hair=0;hair<Nhair;hair++) if (inCharge(hair)){ explicit_scheme(hair); }
        PASOK = dtpasok();
        }
    while (PASOK){
        dt /= 2.;
        std::cout << rank << " dt " << dt << std::endl;
        for (hair=0;hair<Nhair;hair++) if (inCharge(hair)){ explicit_scheme(hair);}
        PASOK = dtpasok();
        }

    if (dt > dtmax) {
      dt = dtmax;
      for (hair=0;hair<Nhair;hair++) if (inCharge(hair)){ explicit_scheme(hair); }
    }
    }

    //update_sub_block();
    //update_solid_velocities();
*/

if(true){
    double rate,err_old;
    nite=0;
    err = 2*err_implocit;
    err_old =  0.;
    rate    = 100.;
    int divideDT = 0;
    while ( (err>err_implocit or rate>10.) and nite<nimplocit ){
    //while ( (err>err_implocit) and nite<nimplocit ){
      err=err_implocit*1e-2;
      for (hair=0;hair<Nhair;hair++) if (inCharge(hair)){ err = std::max(implicit_scheme(hair),err); }
      if (err<err_implocit*1e-2){ rate=0.;}
      else        { rate=err_old/err;}
      err_old = err;
      nite+=1;
      //std::cout << rank << " ddt " << divideDT << " dt " << dt << " err " << err << std::endl;

      PASOK = dtpasok() or nite==nimplocit;
      if (PASOK){
        nite=0;
        err = 2*err_implocit;
        err_old =   0.;
        rate    = 100.;
      //while (PASOK){
        dt /= 2.;
        divideDT++;
        for (hair=0;hair<Nhair;hair++) if (inCharge(hair)){ explicit_scheme(hair); }
        //for (hair=0;hair<Nhair;hair++) if (inCharge(hair)){ err = std::max(implicit_scheme(hair),err); }
        //PASOK = dtpasok();
        //}
       }//else{
        update_sub_block();
        update_solid_velocities();
       //}

      }
    }
    //update geometry
    for (etage=0;etage<nh-1;etage++){
      for (hair=0;hair<Nhair;hair++){
        theta_past(hair,etage) = theta(hair,etage);
        theta(hair,etage) = new_theta(hair,etage);
        X(hair,etage+1) = new_X(hair,etage+1); // no need to update the lowest since always the same
        Y(hair,etage+1) = new_Y(hair,etage+1);
        }
      }
}

void Euler::explicit_scheme(int hair){
  double shear_N,shear_T,interm,a,b;
  int k,n;
  for (n=1;n<nh-2;n++){
    interm = B[n]*(theta(hair,n+1) - 2*theta(hair,n) + theta(hair,n-1))*dt*dt;
    // dissipation term
    interm+= dissip_const(n)*((theta(hair,n+1) - 2*theta(hair,n) + theta(hair,n-1))-(theta_past(hair,n+1) - 2*theta_past(hair,n) + theta_past(hair,n-1)))/dt_Old*dt*dt;

    interm/= dh*dh;//pow(dh,2);

    // shearing force computation   
    shear_N = 0.;
    shear_T = 0.;
    for (k=n;k<nh-1;k++) shear_elem(0,k,hair,n,&shear_N,&shear_T);
    //shear_N *= 1./2.*rhob*Cd*d*dh;
    //shear_T *= 1./2.*rhob*Cd*(M_PI*d)*dh;    
    shear_N *= 1./2.*dh*mu;
    shear_T *= 1./2.*dh*mu;    
    interm += shear_N*dt*dt;
    interm += shear_T*dt*dt;
    interm *= coef;
    a=interm;
    b=(theta(hair,n) - theta_past(hair,n))/dt_Old*dt;
    //interm = b*dt+a*dt*dt;//pow(dt,2);
    interm = b+a;//pow(dt,2);

    new_theta(hair,n) = interm + theta(hair,n);
    //TEMP_theta(hair,n) = interm + theta(hair,n);
    }
  //update for Neumann BC
  new_theta(hair,nh-2) = new_theta(hair,nh-3);
}

double Euler::implicit_scheme(int hair){
  double shear_N,shear_T,interm,a,b,result;
  int k,n;
  result = 0.;
  for (n=1;n<nh-2;n++){
    interm = B[n]*(new_theta(hair,n+1) - 2*new_theta(hair,n) + new_theta(hair,n-1))*dt*dt;//pow(dt,2);
    // dissipation term
    //interm+= coef*dissip_const(n)*((new_theta(hair,n+1) - 2*new_theta(hair,n) + new_theta(hair,n-1))-(theta(hair,n+1) - 2*theta(hair,n) + theta(hair,n-1)))/dt;
    interm+= dissip_const(n)*((new_theta(hair,n+1) - 2*new_theta(hair,n) + new_theta(hair,n-1))-(theta(hair,n+1) - 2*theta(hair,n) + theta(hair,n-1)))*dt;
    interm/= dh*dh;//pow(dh,2);
    // shearing force computation   
    shear_N = 0.;
    shear_T = 0.;
    for (k=n;k<nh-1;k++) shear_elem(1,k,hair,n,&shear_N,&shear_T);
    //shear_N *= 1./2.*rhob*Cd*d*dh*coef;
    //shear_T *= 1./2.*rhob*Cd*(M_PI*d)*dh*coef;
    shear_N *= 1./2.*dh*mu;
    shear_T *= 1./2.*dh*mu;    
    interm += shear_N*dt*dt;//pow(dt,2);
    interm += shear_T*dt*dt;//pow(dt,2);
    interm *= coef;
    a=interm;
    b=(theta(hair,n) - theta_past(hair,n))/dt_Old;
    //interm = b*dt+a*pow(dt,2);
    interm = b*dt+a;
    //std::cout<< hair << "   " << interm <<std::endl;

    result = std::max(abs(new_theta(hair,n) - (interm + theta(hair,n))),result);

    TEMP_theta(hair,n) = interm + theta(hair,n);
    }
  //std::cout<< "...9" <<std::endl;
  //update for Neumann BC
  TEMP_theta(hair,nh-2) = TEMP_theta(hair,nh-3);

  for (n=0;n<nh-1;n++) new_theta(hair,n) = TEMP_theta(hair,n);

  return result;
}

void Euler::update_childrens(){
  broadcast_thetaAndUs_to_childrens();
  draw_childrens();
  setCInterp();
}

void Euler::update_sub_block(){
    update_rotules_position();
    // solid centers
    int hair,etage;
    for (etage=0;etage<nh-1;etage++){
      for (hair=0;hair<Nhair;hair++){
      xInterp(hair,etage) = (new_X(hair,etage+1)+new_X(hair,etage))/2.;
      yInterp(hair,etage) = (new_Y(hair,etage+1)+new_Y(hair,etage))/2.;
      }
      }
    //update_relative_velocities();
}

void Euler::update_rotules_position(){
  int etage,hair;
  for (etage=1;etage<nh;etage++){
    for (hair=0;hair<Nhair;hair++){
      new_X(hair,etage) = new_X(hair,etage-1) + dh*sin(new_theta(hair,etage-1));
      new_Y(hair,etage) = new_Y(hair,etage-1) + dh*cos(new_theta(hair,etage-1));
      }
    }
}
void Euler::interpolate_fluid_velocities_on_solid(){
  //interpolate flow at centers of elementary beams
  int w,i,m,n;
  double dist_test,dmin;
  for (n=0;n<Nhair;n++){
  for (m=0;m<nh-1;m++){
    if (inBlock(xInterp(n,m),yInterp(n,m))){
      i=0;
      dmin = distance(xFDPoints_uv(i),yFDPoints_uv(i),xInterp(n,m),yInterp(n,m));
      w=0;
      for (i=1; i<nuv; i++){
        dist_test = distance(xFDPoints_uv(i),yFDPoints_uv(i),xInterp(n,m),yInterp(n,m));
        if (dist_test < dmin){
          dmin = dist_test;
          w = i;
          }
        }
      uXY(n,m) = u(w);
      vXY(n,m) = v(w);
      //Foam::point P(xInterp(n,m),yInterp(n,m),0.);
      //std::cout << U[maille.findCell(P)][0] << "   " << U[maille.findCell(P)][1] << "   " << uXY(n,m) << "   " << vXY(n,m) << std::endl;
      poroS(n,m) = 1.-solid_fraction_K(w);
      }
    else{
      uXY(n,m) = 0.;
      vXY(n,m) = 0.;
      poroS(n,m) = 0.;
      }
    }
  }

//uXY
int count;
count=0;
for (n=1;n<nh-1;n+=1){
  for (m=0;m<Nhair;m+=1){
    Foam::sumReduce(uXY(m,n), count, Foam::Pstream::msgType(), Foam::UPstream::worldComm);
    Foam::sumReduce(vXY(m,n), count, Foam::Pstream::msgType(), Foam::UPstream::worldComm);
    Foam::sumReduce(poroS(m,n), count, Foam::Pstream::msgType(), Foam::UPstream::worldComm);
    if (poroS(m,n)<0.1) { poroS(m,n) = 0.1; } //bounded for security
    }
  }
  }

bool Euler::dtpasok(){
  int n,m;
  double test;
  for (n=0;n<Nhair;n++){
  if (inCharge(n)){
    //for (m=1;m<nh-2;m++){
    for (m=0;m<nh-2;m++){
      //test = std::fabs(new_theta(n,m+1) - 2*new_theta(n,m) + new_theta(n,m-1)-(theta(n,m+1) - 2*theta(n,m) + theta(n,m-1)));
      test = std::fabs( (new_theta(n,m+1) - new_theta(n,m))-(theta(n,m+1) - theta(n,m)) );
      //test = std::fabs( (new_theta(n,m))-(theta(n,m)) );
//      test = std::fabs(new_theta(n,m+1) - new_theta(n,m));
      //if (test > result) result=test;
      if (test > d/dh*limangle) return true;
      }
    }
    }
//std::cout << result/limangle << "   " << dt << std::endl;
//I = pi*d^4/64
//return result*B_bending/(M_PI*pow(d,4)/64.*rhos)*pow(dt/dh,2) > limangle;
//return result > limangle;
return false;
}

void Euler::shear_elem(int scheme,int k,int hair,int n, double *shear_N, double *shear_T){
  // quadratic drag  
  double result_N,result_T,kuxx,kuyy,lenref,porref;
if ((1.-poroS(hair,k)) < 1e-3){
  result_N = 0.;
  result_T = 0.;
  //std::cout << Foam::UPstream::myProcNo() << std::endl;
  }
else{
  if (scheme == 0){
    permeability( uXY(hair,k)-us_old(hair,k), vXY(hair,k)-vs_old(hair,k), poroS(hair,k), theta(hair,k), &kuxx,&kuyy,lenref,porref);
    result_N= kuxx*cos(theta(hair,k)) - kuyy*sin(theta(hair,k));
    result_T= kuxx*sin(theta(hair,k)) + kuyy*cos(theta(hair,k));
    result_N*= poroS(hair,k)*poroS(hair,k);
    result_T*= poroS(hair,k)*poroS(hair,k);
    result_N*= cos(theta(hair,k)-theta(hair,n));
    result_T*= sin(theta(hair,k)-theta(hair,n));
    }    
  else if (scheme == 1){
    permeability( uXY(hair,k)-us(hair,k), vXY(hair,k)-vs(hair,k), poroS(hair,k), new_theta(hair,k), &kuxx,&kuyy,lenref,porref);
    result_N= kuxx*cos(new_theta(hair,k)) - kuyy*sin(new_theta(hair,k));
    result_T= kuxx*sin(new_theta(hair,k)) + kuyy*cos(new_theta(hair,k));
    result_N*= poroS(hair,k)*poroS(hair,k);
    result_T*= poroS(hair,k)*poroS(hair,k);
    result_N*= cos(new_theta(hair,k)-new_theta(hair,n));
    result_T*= sin(new_theta(hair,k)-new_theta(hair,n));
    }
  else{
    result_N = 0.;
    result_T = 0.;
    std::cout<< "invalid option scheme" <<std::endl;
    }
  }
  (*shear_N)+=result_N;
  (*shear_T)+=result_T;
}

void Euler::incrTime_updateTimeSteps(){
  S_time += dt;
  dt_Old = dt;
}

void Euler::plotting_block(int ite, int rank){
  //Foam::Info << "SOLVING EULER. ITE " << ite+1 << " SOLID TIME " << S_time << " s , dt = " << dt << " s." << Foam::endl;
  std::cout << rank << " SOLVING EULER. ITE " << ite+1 << " SOLID TIME " << S_time << " s , dt = " << dt << " s." << std::endl;
  }

double Euler::get_time(){
return  S_time;
}

void Euler::sendToProcs(){
int etage,hair,count;
count=0;
for (hair=0;hair<Nhair;hair++){
  for (etage=0;etage<nh-1;etage++){
    if (inCharge(hair)){}
    else{
      us(hair,etage) = 0.;
      vs(hair,etage) = 0.;
      theta(hair,etage) = 0.;
      }
    Foam::sumReduce(us(hair,etage), count, Foam::Pstream::msgType(), Foam::UPstream::worldComm);
    Foam::sumReduce(vs(hair,etage), count, Foam::Pstream::msgType(), Foam::UPstream::worldComm);
    Foam::sumReduce(theta(hair,etage), count, Foam::Pstream::msgType(), Foam::UPstream::worldComm);
    }
  }
}
