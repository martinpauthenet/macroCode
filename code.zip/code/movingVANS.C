/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     |
    \\  /    A nd           | Copyright (C) 2011-2013 OpenFOAM Foundation
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM.  If not, see <http://www.gnu.org/licenses/>.

Application
    icoFoam

Description
    Transient solver for incompressible, laminar flow of Newtonian fluids.

\*---------------------------------------------------------------------------*/

//#include "kdtree.H"
#include "eulerClass.H"

#include "fvCFD.H"
//#include "pisoControl.H"
#include "pimpleControl.H"
#include "singlePhaseTransportModel.H"
#include "turbulenceModel.H"


// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

int main(int argc, char *argv[])
{
    #include "setRootCase.H"
    #include "createTime.H"
    #include "createMesh.H"
    //pisoControl piso(mesh);
    pimpleControl piso(mesh);
    #include "createFields.H"
    #include "initContinuityErrs.H"
    #include "readTimeControls.H" 

    // * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

scalar flag_k_update = readScalar(transportProperties.lookup("k_update"));
scalar flag_source_update = readScalar(transportProperties.lookup("source_update"));
scalar flowRate_objectif = readScalar(transportProperties.lookup("objectif"));
scalar flag_canopy_update = readScalar(transportProperties.lookup("canopy_update"));
scalar max_ite_solid = readScalar(transportProperties.lookup("max_ite_solid"));
dimensionedScalar gain = 1.;

int nSamples = 1778498;
// number of parameters in the metamodel
int dimx = 4;
// number of outputs, the 3 elements of the permeability tensor
int dimy = 3;
// matrix for the input parameters
Eigen::Matrix<double, Dynamic, Dynamic>  mat(nSamples, dimx);
// matrix for the output results
Eigen::Matrix<double, Dynamic, Dynamic>  maty(nSamples, dimy);
// name of the file in which the database is saved
char* res = "result.dat";
read_file(mat, maty, res);
KDTreeEigenMatrixAdaptor< Eigen::Matrix<double,Dynamic,Dynamic>,nanoflann::metric_L2> mat_index(mat, 20 );
kdtree_build<double>(mat_index, nSamples /* samples */, dimx /* dim */, dimy);
    
    // * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

    Info << "creates canopy..." << endl;
    double ly;
    scalar temps = runTime.value();
    Euler canopy(mesh, U, mat_index, maty, &ly,temps);
    canopy.initialize_solid_phase();

  int nproc,thisproc,nProcsTot,dummy;
  nProcsTot = UPstream::nProcs();
  thisproc = UPstream::myProcNo();
  //Nhair = canopy.get_Nhair();
  //nh = canopy.get_nh();
  //thisHair = canopy.get_fiberNumber();

  for (nproc=0;nproc<nProcsTot;nproc++){
   Pstream::scatter(dummy, Pstream::blocking);
   if (nproc==UPstream::myProcNo()){
     std::cout << "proc rank " << thisproc << " X " << canopy.getxmin() << "   " << canopy.getxmax() << std::endl;
     std::cout << "proc rank " << thisproc << " Y " << canopy.getymin() << "   " << canopy.getymax() << std::endl;
     }
   }

Foam::List<int> intToSend(nProcsTot);
Foam::List<double> doubleToSend(nProcsTot);

    dimensionedScalar Lunite ( "Lunite", dimensionSet(0,1,0,0,0,0,0), 1. );

    // * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

    canopy.broadcast_thetaAndUs_to_childrens();
    Info << "spread_solid_fraction" << endl;
    canopy.spread_solid_fraction();

  Info<< "reads canopy kinematics..." << endl;
  double as,us,vs;
  forAll(U, iuv){
    canopy.solid_coordinates(iuv, &as, &us, &vs ); //finds nearest elementary beam
    angleS[iuv]=as;
    Us[iuv][0] =us;
    Us[iuv][1] =vs;
    por[iuv] = std::max(1.-canopy.local_solid_fraction(iuv),2e-1); //finds nearest point of the mesh used to compute the solid fraction and returns
    phaseS[iuv] = canopy.get_phaseS(iuv); //finds nearest point of the mesh used to compute the solid fraction and returns
    }

    Info<< "\nStarting time loop\n" << endl;

    while (runTime.loop())
    {
        Info<< "Time = " << runTime.timeName() << nl << endl;

        #include "CourantNo.H"
        #include "setDeltaT.H"

scalar old_t(runTime.times()[runTime.times().size()-1].value());
word old_t_word = name(old_t);

if (flag_k_update == 1){ 
Info << "Updating K" << endl;
  double kuxx,kuyy,lenref;
  double uxy,vxy,dummy_double;
  canopy.set_Cauchy_tozero();
  forAll(KU, j){
    //if( K[j].xx() != 0.){
        uxy = U[j][0]-Us[j][0];
        vxy = U[j][1]-Us[j][1];
        if ((1.-por[j]) < 1e-3){
          KU[j][0] = 0.;
          KU[j][1] = 0.;
          }
        else{
          canopy.permeability(uxy,vxy,por[j],angleS[j],&kuxx,&kuyy,lenref,dummy_double);//update the permeability tensor
          KU[j][0] = kuxx/(lenref*lenref);//std::pow(lenref,2);
          KU[j][1] = kuyy/(lenref*lenref);//std::pow(lenref,2);
          }
    } 
  int count;
  double cauch, reynol, maxCauch, maxRe;
  count=0;
  maxCauch = 0.;
  maxRe = 0.;
  for (nproc=0;nproc<nProcsTot;nproc++){
    cauch = 0.;
    reynol = 0.;
    if (nproc==UPstream::myProcNo()){      
      cauch = canopy.max_Cauchy();
      reynol = canopy.max_Reynolds();
      }
    Foam::sumReduce(cauch, count, Foam::Pstream::msgType(), Foam::UPstream::worldComm);
    Foam::sumReduce(reynol, count, Foam::Pstream::msgType(), Foam::UPstream::worldComm);
    if (UPstream::myProcNo()==0){
        if (maxCauch < cauch){
          maxCauch = cauch;
          }
        if (maxRe < reynol){
          maxRe = reynol;
          }
      }
    }
  Info<< " Cauchy number " << maxCauch << endl;
  Info<< " Reynolds number " << maxRe << endl;
  }
else{ 
  Info << "Not updating K" << endl;
  }
        fvVectorMatrix UEqn
        (
            fvm::ddt(U)
          + fvm::div(phi, U)

          + turbulence->divDevReff(U)

          //- fvm::laplacian(nu, U)
          - gravity * gain
	  //+ fvc::Sp(1.,KU)
	  //+ KU
          //+ (1/por)*fvm::div(phi*phiPor, U)
          //- fvm::laplacian(nu, U)
          //- (nu/por)* (fvc::grad(U) & fvc::grad(por)) //gradPorgradU
          //- (nu/por)*fvc::laplacian(por) * U
          //- gravity
	  + fvc::Sp(por*nu/(Lunite*Lunite),KU)
        );

        if (piso.momentumPredictor())
        {
            solve(UEqn == -fvc::grad(p));
        }

        // --- PISO loop
        while (piso.correct())
        {
            volScalarField rAU(1.0/UEqn.A());

            volVectorField HbyA("HbyA", U);
            HbyA = rAU*UEqn.H();
            surfaceScalarField phiHbyA
            (
                "phiHbyA",
                (fvc::interpolate(HbyA) & mesh.Sf())
              + fvc::interpolate(rAU)*fvc::ddtCorr(U, phi)
            );

            adjustPhi(phiHbyA, U, p);

            // Non-orthogonal pressure corrector loop
            while (piso.correctNonOrthogonal())
            {
                // Pressure corrector

                fvScalarMatrix pEqn
                (
                    fvm::laplacian(rAU, p) == fvc::div(phiHbyA)
                );

                pEqn.setReference(pRefCell, pRefValue);

                pEqn.solve(mesh.solver(p.select(piso.finalInnerIter())));

                if (piso.finalNonOrthogonalIter())
                {
                    phi = phiHbyA - pEqn.flux();
                }
            }

            #include "continuityErrs.H"

            U = HbyA - rAU*fvc::grad(p);
            U.correctBoundaryConditions();
        }

        turbulence->correct();

///////////////////////////////////////////////////////////////////////////////////
//runTime.write(); // to write th time

if (flag_canopy_update == 1){

  Info << "updating canopy" << endl;
  temps = runTime.value();

  int plo,i,count;
  plo=0;
  i=0;
  count=0;

  //Info << "solid phase is " << temps - canopy.get_time() << " s late." << endl;
  std::cout << thisproc << " solid phase is " << temps - canopy.get_time() << " s late." << std::endl;
  //while ( temps - canopy.get_time() > 1e-2*canopy.get_time_scale() && i < max_ite_solid){
  int isinLoop;
  while ( temps - canopy.get_time() > 0. && i < max_ite_solid){

    isinLoop = 1;
    Foam::sumReduce(isinLoop, count, Foam::Pstream::msgType(), Foam::UPstream::worldComm);
    canopy.interpolate_fluid_velocities_on_solid();

    canopy.nextShapes(temps,thisproc);
    canopy.incrTime_updateTimeSteps();
    plo++;
    if (plo > 0){
      canopy.plotting_block(i,thisproc);
      plo=0;
      };
    i++;
    }
  isinLoop = 0;
  Foam::sumReduce(isinLoop, count, Foam::Pstream::msgType(), Foam::UPstream::worldComm);
  // for other procs that are still inside the loop
  while(isinLoop>0){
    isinLoop = 0;
    canopy.interpolate_fluid_velocities_on_solid();
    Foam::sumReduce(isinLoop, count, Foam::Pstream::msgType(), Foam::UPstream::worldComm);
    }
  //here we must send the correct orientation, us and vs to all processors
if (nProcsTot>1){

canopy.sendToProcs();

}

  canopy.update_childrens();
  canopy.draw_hairs(); //for hairs that are not in proc
  canopy.setInterp();  //for hairs that are not in proc
  
  //Info << "solid phase is " << temps - canopy.get_time() << " s late." << endl;
  std::cout << thisproc << " solid phase is " << temps - canopy.get_time() << " s late." << std::endl;
  canopy.spread_solid_fraction();

  Info << "reads canopy kinematics..." << endl;
  //int m,n;
  double as,us,vs;
  forAll(U, iuv){
    canopy.solid_coordinates(iuv, &as, &us, &vs ); //finds nearest elementary beam
    angleS[iuv]=as;
    Us[iuv][0] =us; 
    Us[iuv][1] =vs;
    por[iuv] = std::max(1.-canopy.local_solid_fraction(iuv),2e-1); //finds nearest point of the mesh used to compute the solid fraction and returns
    phaseS[iuv] = canopy.get_phaseS(iuv); //finds nearest point of the mesh used to compute the solid fraction and returns
  //std::cout << UPstream::myProcNo() << "   " << iuv << std::endl;
  }
}
else{ Info << "Not moving canopy" << endl;}

  //forAll(U, iuv){uv[iuv] = U[iuv][0] * U[iuv][1];} // to compute Reynolds stresses

  runTime.write(); // to write all

  scalar flowRate = fvc::domainIntegrate(U).value()[0]/sum(mesh.V()).value();

        if (flag_source_update==1){
          Info << "adjust gain" << endl;
          if (flowRate > flowRate_objectif*1.1) { gain = gain * 0.9; }
          if (flowRate < flowRate_objectif*0.8) { gain = gain * 1.01; }
          }

        Info<< "Averaged velocity <U> = " << flowRate << "  gain set to " << gain.value() <<  endl;

        Info<< "ExecutionTime = " << runTime.elapsedCpuTime() << " s"
            << "  ClockTime = " << runTime.elapsedClockTime() << " s"
            << nl << endl;
    }

    Info<< "End\n" << endl;

    return 0;
}


// ************************************************************************* //
